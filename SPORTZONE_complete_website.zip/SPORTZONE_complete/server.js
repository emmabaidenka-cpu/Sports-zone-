require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Parser = require("rss-parser");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const parser = new Parser({ timeout: 12000 });
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const ARTICLES_FILE = path.join(DATA_DIR, "articles.json");

if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD_HASH) {
  console.warn("SETUP REQUIRED: copy .env.example to .env and set SESSION_SECRET and ADMIN_PASSWORD_HASH.");
}
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ARTICLES_FILE)) fs.writeFileSync(ARTICLES_FILE, "[]", "utf8");

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "sportzone.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function readArticles() {
  try { return JSON.parse(fs.readFileSync(ARTICLES_FILE, "utf8")); }
  catch { return []; }
}
function writeArticles(items) {
  fs.writeFileSync(ARTICLES_FILE, JSON.stringify(items, null, 2), "utf8");
}
function cleanText(value, max = 10000) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function safeArticle(body) {
  const title = cleanText(body.title, 180);
  const category = cleanText(body.category, 60) || "Other Sports";
  const author = cleanText(body.author, 100) || "SPORTZONE Desk";
  const summary = cleanText(body.summary, 500);
  const articleBody = cleanText(body.body, 20000);
  const image = cleanText(body.image, 1000);
  if (!title || !summary || !articleBody) return { error: "Title, summary and article text are required." };
  if (image && !/^https:\/\/.+/i.test(image)) return { error: "Image must use an https:// address." };
  return { title, category, author, summary, body: articleBody, image };
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Please sign in as an administrator." });
}

app.get("/api/articles", (req, res) => {
  const articles = readArticles()
    .filter(a => a.published)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(articles);
});

app.get("/api/admin/session", (req, res) => {
  res.json({ authenticated: !!(req.session && req.session.isAdmin) });
});

app.post("/api/admin/login", async (req, res) => {
  const username = cleanText(req.body.username, 100);
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const expectedUser = process.env.ADMIN_USERNAME || "admin";
  const hash = process.env.ADMIN_PASSWORD_HASH || "";
  if (!hash || username !== expectedUser || !(await bcrypt.compare(password, hash))) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a secure session." });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/admin/articles", requireAdmin, (req, res) => {
  res.json(readArticles().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
});

app.post("/api/admin/articles", requireAdmin, (req, res) => {
  const clean = safeArticle(req.body);
  if (clean.error) return res.status(400).json({ error: clean.error });
  const article = {
    id: crypto.randomUUID(),
    ...clean,
    createdAt: new Date().toISOString(),
    published: req.body.published !== false
  };
  const items = readArticles();
  items.push(article);
  writeArticles(items);
  res.status(201).json(article);
});

app.put("/api/admin/articles/:id", requireAdmin, (req, res) => {
  const clean = safeArticle(req.body);
  if (clean.error) return res.status(400).json({ error: clean.error });
  const items = readArticles();
  const index = items.findIndex(a => a.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "Article not found." });
  items[index] = { ...items[index], ...clean, published: req.body.published !== false };
  writeArticles(items);
  res.json(items[index]);
});

app.delete("/api/admin/articles/:id", requireAdmin, (req, res) => {
  const items = readArticles();
  const remaining = items.filter(a => a.id !== req.params.id);
  if (remaining.length === items.length) return res.status(404).json({ error: "Article not found." });
  writeArticles(remaining);
  res.json({ ok: true });
});

const FEEDS = [
  { name: "BBC Sport", url: "https://feeds.bbci.co.uk/sport/rss.xml" },
  { name: "ESPN", url: "https://www.espn.com/espn/rss/news" },
  { name: "Citi Sports Online", url: "https://citinewsroom.com/category/sports/feed/" }
];
app.get("/api/external-news", async (req, res) => {
  const results = await Promise.all(FEEDS.map(async feed => {
    try {
      const data = await parser.parseURL(feed.url);
      return (data.items || []).slice(0, 8).map(item => ({
        source: feed.name,
        title: cleanText(item.title, 250),
        link: /^https?:\/\//i.test(item.link || "") ? item.link : "",
        publishedAt: item.isoDate || item.pubDate || "",
        summary: cleanText((item.contentSnippet || item.summary || "").replace(/<[^>]*>/g, " "), 350)
      })).filter(item => item.title && item.link);
    } catch (error) {
      console.error(`RSS feed failed (${feed.name}): ${error.message}`);
      return [];
    }
  }));
  res.set("Cache-Control", "public, max-age=300");
  res.json({ feeds: FEEDS.map(f => f.name), items: results.flat().sort((a, b) => new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0)).slice(0, 24) });
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`SPORTZONE is running at http://localhost:${PORT}`));
